# Проект: Место

### Обзор

* Figma
* Картинки

**Figma**

* [Ссылка на макет в Figma](https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1)
* [Ссылка на сайт на GitHub](https://kirillsergeenko.github.io/mesto/)
## Описание
Проект Место - сайт по типу Инстаграм, где можно будет добавлять фотогграфии, редактировать профиль, лайкать фото.

Проект использует верстку html и css.
Добавлена верстка форм
Добавлен  яваскрипт: 
Использованы переменные, функции и константы.
использованы методы: querySelector(), addEventListener, методы classList.
использованы свойства: .textContent;

